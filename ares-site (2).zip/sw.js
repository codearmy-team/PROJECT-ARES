const C='ares-v9',F=['/game.html','/manifest.webmanifest','/icon-192.png','/icon-512.png','/icon-1024.png','/icon-maskable-512.png'];
const clean=async r=>r.redirected?new Response(await r.blob(),{status:200,headers:r.headers}):r;
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>Promise.all(F.map(u=>fetch(u).then(clean).then(r=>c.put(u,r)).catch(()=>{})))));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{const q=e.request;if(q.method!=='GET'||new URL(q.url).origin!==location.origin)return;const nav=q.mode==='navigate';
e.respondWith(fetch(q).then(clean).then(r=>{if(r.ok){const c=r.clone();caches.open(C).then(x=>x.put(nav?'/game.html':q,c));return r;}
if(nav)return fetch('/game.html').then(clean).then(g=>g.ok?g:r).catch(()=>caches.match('/game.html').then(m=>m||r));return r;})
.catch(()=>caches.match(nav?'/game.html':q).then(r=>r||caches.match('/game.html'))));});
